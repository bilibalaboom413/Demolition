package demolition;

public class Goal extends Space {
    
    /**
     * Constructor of the Space
     * @param x the x-coordinate
     * @param y the y-coordinate
     */
    public Goal(int x, int y) {
        super(x, y);
    }
}
