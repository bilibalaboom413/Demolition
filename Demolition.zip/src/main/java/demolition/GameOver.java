package demolition;

public class GameOver extends Space {

    /**
     * Constructor of the GameOver
     * @param x the x-coordinate
     * @param y the y-coordinate
     */
    public GameOver(int x, int y) {
        super(x, y);
    }
}
