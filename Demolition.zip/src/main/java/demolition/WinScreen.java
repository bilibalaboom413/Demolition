package demolition;

public class WinScreen extends Space {

    /**
     * Constructor of the WinScreen
     * @param x the x-coordinate
     * @param y the y-coordinate
     */
    public WinScreen(int x, int y) {
        super(x, y);
    }
}
