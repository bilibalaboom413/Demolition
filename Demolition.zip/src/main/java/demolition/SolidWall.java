package demolition;

public class SolidWall extends Space {
    
    /**
     * Constructor of the solid wall
     * @param x the x-coordinate
     * @param y the y-coordinate
     */
    public SolidWall(int x, int y) {
        super(x, y);
    }
}
